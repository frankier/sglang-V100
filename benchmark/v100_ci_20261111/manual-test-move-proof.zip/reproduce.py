from pathlib import Path
from mechanical_refactor_reproduction_utils import verify_mechanical_refactor, git_add_and_commit

BASE = '4cf2df9531dde40f6083fc7913c2149494f6d6c8'
TARGET = '193c636ada7d42f81e353f03f92bee0ac268410b'
MOVES = {'test/registered/unit/hybrid_linear/test_deferred_mamba_state_ops.py': 'test/manual/hybrid_linear/test_deferred_mamba_state_ops.py', 'test/registered/unit/layers/attention/test_bfla_sparse_sm70.py': 'test/manual/kernels/attention/test_bfla_sparse_sm70.py', 'test/registered/unit/layers/attention/test_gdn_tilelang_sm70.py': 'test/manual/kernels/attention/test_gdn_tilelang_sm70.py', 'test/registered/unit/layers/attention/test_paged_decode_tilelang_sm70.py': 'test/manual/kernels/attention/test_paged_decode_tilelang_sm70.py', 'test/registered/unit/layers/attention/test_qwen_sparse_sm70_routing.py': 'test/manual/kernels/attention/test_qwen_sparse_sm70_routing.py', 'test/registered/unit/layers/attention/test_sm70_fp8_kv_scratch.py': 'test/manual/kernels/attention/test_sm70_fp8_kv_scratch.py', 'test/registered/unit/layers/moe/test_sm70_nvfp4_moe_decode.py': 'test/manual/kernels/moe/test_sm70_nvfp4_moe_decode.py', 'test/registered/unit/layers/quantization/test_sm70_turbomind_awq.py': 'test/manual/kernels/quantization/test_sm70_turbomind_awq.py', 'test/registered/unit/layers/quantization/test_sm70_turbomind_fp8.py': 'test/manual/kernels/quantization/test_sm70_turbomind_fp8.py', 'test/registered/unit/layers/test_greedy_tp_top1.py': 'test/manual/layers/test_greedy_tp_top1.py', 'test/registered/unit/layers/test_tilelang_gemma_rmsnorm_sm70.py': 'test/manual/kernels/elementwise/test_tilelang_gemma_rmsnorm_sm70.py', 'test/registered/unit/spec/test_dflash2.py': 'test/manual/spec/test_dflash2.py', 'test/registered/unit/spec/test_eagle_worker_v2_import.py': 'test/manual/spec/test_eagle_worker_v2_import.py', 'test/registered/unit/spec/test_v100_speculative.py': 'test/manual/spec/test_v100_speculative.py'}

def transform(root: Path):
    for source, target in MOVES.items():
        src, dst = root / source, root / target
        dst.parent.mkdir(parents=True, exist_ok=True)
        src.rename(dst)
    git_add_and_commit("reproduce manual test moves", cwd=str(root))

if __name__ == "__main__":
    verify_mechanical_refactor(BASE, TARGET, transform)
